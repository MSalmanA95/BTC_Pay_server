namespace BTCPayServer.Abstractions.Contracts
{
    public interface IUIExtension
    {
        string Partial { get; }

        string Location { get; }
    }
}
