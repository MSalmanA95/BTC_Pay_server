namespace BTCPayServer.Abstractions.Models
{
    public class DatabaseOptions
    {
        public string ConnectionString { get; set; }
    }
}
