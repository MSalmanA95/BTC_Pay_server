namespace BTCPayServer.Client.Models
{
    public class ServerEmailSettingsData : EmailSettingsData
    {
        public bool EnableStoresToUseServerEmailSettings { get; set; }
    }
}
