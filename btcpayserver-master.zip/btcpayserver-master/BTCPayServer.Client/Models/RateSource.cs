namespace BTCPayServer.Client.Models;

public class RateSource
{
    public string Id { get; set; }
    public string Name { get; set; }
}
