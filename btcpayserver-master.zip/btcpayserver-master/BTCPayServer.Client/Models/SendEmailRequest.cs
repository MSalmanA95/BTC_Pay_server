
namespace BTCPayServer.Client.Models
{
    public class SendEmailRequest
    {
        public string Email;
        public string Subject;
        public string Body;
    }
}
