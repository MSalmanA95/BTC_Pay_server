namespace BTCPayServer.Client.Models
{
    public class ApiHealthData
    {
        public bool Synchronized { get; set; }
    }
}
