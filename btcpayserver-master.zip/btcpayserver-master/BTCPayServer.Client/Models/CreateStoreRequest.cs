namespace BTCPayServer.Client.Models
{
    public class CreateStoreRequest : StoreBaseData
    {
    }
}
