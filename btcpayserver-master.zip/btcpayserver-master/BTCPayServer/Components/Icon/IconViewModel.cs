namespace BTCPayServer.Components.Icon;

public class IconViewModel
{
    public string Symbol { get; set; }
    public string CssClass { get; set; }
}
