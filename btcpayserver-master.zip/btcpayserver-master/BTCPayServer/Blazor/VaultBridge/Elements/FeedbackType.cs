﻿namespace BTCPayServer.Blazor.VaultBridge.Elements;

public enum FeedbackType
{
    Loading,
    Success,
    Failed
}
